from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
	return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
	# process gross pay
	rate = int( request.form['rate'] )
	ot_rate = int( request.form['ot_rate'] )
	totWorkHours = int( request.form['work_hours'] )
	totOT = int( request.form['ot'] )

	total_reg = round( rate * totWorkHours )
	total_ot = round( ot_rate * totOT )
	gross = total_reg + total_ot
	# process deductions

	sss = int( request.form['sss'] )
	pagibig = int( request.form['pagibig'] )
	tax = int( request.form['tax'] )
	philhealth = int( request.form['philhealth'] )
	sss_loan = int( request.form['sss_loan'] )
	pagibig_loan = int( request.form['pagibig_loan'] )
	late = int( request.form['late'] )
	absent = int( request.form['absent'] )
	others = int( request.form['others'] )

	deductions = ( sss + pagibig + tax + philhealth + sss_loan + pagibig_loan + late + absent + others )
	# total
	net_pay = int( gross - deductions )

	return render_template(
				'result.html', 
				total_reg = '₱ ' + str(total_reg),
				total_ot = '₱ ' + str(total_ot),
				gross = '₱ ' + str(gross),
				deductions = '₱ ' + str(deductions),
				net_pay = '₱ ' + str(net_pay),
			)

app.run(debug=True)