from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
	return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
	# process grade
	prelim = int( request.form['prelim'] )
	midterm = int( request.form['midterm'] )
	finals = int( request.form['finals'] )

	# formula
	cmg = round( ( ( ( midterm * 2 ) + prelim ) / 3 ), 2 )
	cfg = round( ( ( ( finals * 2 ) + float(cmg) ) / 3 ), 2 )

	return render_template(
				'result.html', 
				cmg = str(cmg),
				cfg = str(cfg),
			)

app.run(debug=True)